<!--
  Copyright seL4 Project a Series of LF Projects, LLC.
  SPDX-License-Identifier: CC-BY-SA-4.0
-->

# seL4 Logo

The seL4 logo. Use for referring to the seL4 microkernel, the seL4
website, or to show off your work on or around the kernel.

The logos in this directory are trademark and copyright protected,
license is granted only under the [seL4 trademark guidelines][tm].

For a copy of the seL4 Foundation logo, please contact
<trademark@sel4.systems>.

[tm]: https://seL4.systems/Foundation/Trademark/
